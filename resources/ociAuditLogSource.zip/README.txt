Content
Sources: [omc_ociAuditLogSource]
Parsers: [IAM Audit Log Format]
Fields: [IAM Actor Name, IAM Actor Type, IAM Admin Resource Type, IAM Admin Target Name, IAM Admin Target Type, IAM AppRole App, IAM Client IP, IAM Domain ID, IAM Domain Name, IAM EventID, IAM Hostname, IAM Identity Provider, IAM Identity Provider Type, IAM Resource Name, IAM Resource Type, IAM SSO Comments, IAM SSO RP, IAM Session ID]

Reference
Parsers: [oci_audit_unifmt_logtype, omc_oci_audit_logtype_v2]
Functions: [Geolocation]
Fields: [availdomain, cityclnt, compartmentid, compartmentname, continentclnt, continentcodeclnt, countryclnt, countrycodeclnt, endeventtime, event, eventsrc, geolocclnt, mbody, regionclnt, regioncodeclnt, reqid, srcip, tenant, type, usrname]
